﻿$(document).ready(function () {
    populateJqueryData();
});

//Function to populate JSON Data
function populateJqueryData() {
    $.ajax({
        type: 'get',
        url: './GetList/populateJQueryData', //JSON Method to be called
        success: function (data) {

            //The Div to be populated
            $('#JQueryData').empty();
            content = "";
            //Looping thru each record
            $.each(data, function (i, record) {
                //Properties available in Model
                //We need to specify the properties in our model
                content += "<tr><td>" + record.Id + "</td><td>" + record.Name + "</td><td>" + record.Location + "</td></tr>";
                
            });
            table="<table>"+content+"</table>"
            $(table).appendTo('#JQueryData');
        },
        error: function (response) {
            alert(response.Message);
        },
        dataType: 'json'
    });
}
