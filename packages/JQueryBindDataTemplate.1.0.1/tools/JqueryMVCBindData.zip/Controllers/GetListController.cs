﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class GetListController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }


        public JsonResult populateJQueryData()
        {
            var data = getMockData();// Populate data from Entity Framework/Services/Model
            return Json(data,JsonRequestBehavior.AllowGet);
        }
        //This is just a mock data
        //We can remove this method, After populating the actual data
        private List<SampleModel> getMockData()
        {
            List<SampleModel> sampleList = new List<SampleModel> { 
            new SampleModel(){Id=1,Name="Chandra Shekar Thota",Location="Redmond"},
            new SampleModel(){Id=2,Name="Anusha Nukala",Location="Machilipatinam"},
            new SampleModel(){Id=3,Name="Soumya",Location="Pragathi Nagar"},
            new SampleModel(){Id=4,Name="Sravya",Location="Kukatpally"},
            new SampleModel(){Id=5,Name="Mano Vikas",Location="Hyderabad"},
            new SampleModel(){Id=6,Name="Sandeep",Location="Secunderabad"},
            new SampleModel(){Id=7,Name="Aradhana",Location="Bellevue"}
            };

            return sampleList;
        }


    }
}
